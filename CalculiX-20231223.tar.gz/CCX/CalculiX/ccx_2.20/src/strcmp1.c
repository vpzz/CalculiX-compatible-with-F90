/*     CalculiX - A 3-dimensional finite element program                 */
/*              Copyright (C) 1998-2022 Guido Dhondt                          */

/*     This program is free software; you can redistribute it and/or     */
/*     modify it under the terms of the GNU General Public License as    */
/*     published by the Free Software Foundation(version 2);    */
/*                                                                       */

/*     This program is distributed in the hope that it will be useful,   */
/*     but WITHOUT ANY WARRANTY; without even the implied warranty of    */
/*     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the      */
/*     GNU General Public License for more details.                      */

/*     You should have received a copy of the GNU General Public License */
/*     along with this program; if not, write to the Free Software       */
/*     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.         */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "CalculiX.h"
// 判断s1和s2是否一方是另一方的连续首子串，例如abc和abcd, abc和ab都符合
// 如果是的话,返回0
// s1和s2的地位又不完全对等，因为作者假设s1为变化的字符串，s2为固定字符串
ITG strcmp1(const char* s1, const char* s2) {
  ITG a, b;

  do {
    a = *s1++;
    b = *s2++;

    /* the statement if((a=='\0')||(b=='\0')) has been treated separately
       in order to avoid the first field (s1) to be defined one longer
       than required; s1 is assumed to be a variable field, s2 is
       assumed to be a fixed string */

    if (b == '\0') {
      a = '\0';
      b = '\0';
      break;
    }
    if (a == '\0') {
      a = '\0';
      b = '\0';
      break;
    }
  } while (a == b);
  return (a - b);
}
