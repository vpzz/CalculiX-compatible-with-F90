#ifndef _EGraph_
#define _EGraph_
#include "EGraph/EGraph.h"
#endif
