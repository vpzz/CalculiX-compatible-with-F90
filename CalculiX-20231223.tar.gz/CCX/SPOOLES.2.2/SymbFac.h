#ifndef _SymbFac_
#define _SymbFac_
#include "SymbFac/SymbFac.h"
#endif
